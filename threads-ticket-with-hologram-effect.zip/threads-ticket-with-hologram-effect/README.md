# Threads ticket with Hologram Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/ethanalaimo/pen/YzoEega](https://codepen.io/ethanalaimo/pen/YzoEega).

recreation of that cool Threads invite ticket.
yeah yeah... i do way too much holographic stuff, haha!